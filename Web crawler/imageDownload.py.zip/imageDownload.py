
import urllib

url_array = []
file_name = 'sampleOutput.txt'

def read_text(file):
    with open(file) as f:
        for line in f:
            #remove new line using rstrip
            #replace the space using %20
            if(line[:1] != 'P'):
                url_array.append(line.rstrip().replace(" ","%20"))

def download_image():
    # image = url_array[857]
    # urllib.urlretrieve(image,image.rsplit('/',1)[1])
    for web_link in url_array:
        image_name = web_link.rsplit('/',1)[1]
        urllib.urlretrieve(web_link,image_name)

def main():
    read_text(file_name)

    download_image()

    print "Finished !!"

if __name__== "__main__":
    main()